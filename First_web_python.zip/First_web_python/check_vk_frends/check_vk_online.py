import requests
import json
import urllib.parse
import sys


def get_friends_online(user_id):
    access_token = 'ec5305c279af3b18e4fa7e68a1863adb12ab138078ad9a901fc4225b99d47da07eb14c0eb7babf2150351'
    params = {
        'access_token': access_token,
        'v': '5.52',
        'user_id': user_id
    }
    url_params = urllib.parse.urlencode(params)
    url = 'https://api.vk.com/method/friends.getOnline?' + url_params
    array_id = requests.get(url).json()
    return array_id

def get_names_of_friends(array_id):
    data = {
        'user_ids': array_id,
        'name_case': 'nom'
    }
    url_params = urllib.parse.urlencode(data)
    url = 'https://api.vk.com/method/users.get?' + url_params
    people_data = requests.get(url)
    people = people_data.json()
    return people

def print_data_in_console(ids):
    for user in ids['response']:
        print(user['first_name'])
        print(user['last_name'])
        print(user['uid'])
        print('\n')
    return 0

if __name__ == '__main__':
    try:
        user_id = sys.argv[1]
        array_id = get_friends_online(user_id)
        ids = get_names_of_friends(array_id)
        print_data_in_console(ids)
        with open('data_jobs.json', 'w', encoding='utf-8') as outfile:
            json.dump(ids, outfile, sort_keys=True, indent=4, ensure_ascii=False)
    except IndexError:
        print('Не обнаружен ID')
        exit()
