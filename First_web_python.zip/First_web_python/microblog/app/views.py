from flask import render_template, flash, redirect
from app import app
from .forms import LoginForm
import urllib
import requests


def get_friends_online(user_id):
    access_token = '9c2744f8c8ae6fce5006d8c364e05ea99814a9c72ce9f63d4a541914245cdec3a5f2a52846bac6f2835ef'
    params = {
        'access_token': access_token,
        'v': '5.52',
        'user_id': user_id
    }
    url_params = urllib.parse.urlencode(params)
    url = 'https://api.vk.com/method/friends.getOnline?' + url_params
    array_id = requests.get(url).json()
    return array_id

def get_names_of_friends(array_id):
    data = {
        'user_ids': array_id,
        'name_case': 'nom'
    }
    url_params = urllib.parse.urlencode(data)
    url = 'https://api.vk.com/method/users.get?' + url_params
    people_data = requests.get(url)
    people = people_data.json()
    return people

@app.route('/index', methods=['GET', 'POST'])
def index():
    form = LoginForm()
    if form.validate_on_submit():
        array_id = get_friends_online(form.openid.data)
        form.openid.data = get_names_of_friends(array_id)
        flash(form.openid.data)
        return redirect('/index')
    return render_template('index.html',
                           title='Sign In',
                           form=form,)
